package Modelo.Conexion;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/*** @author Licoreria
 */
public class Conexion {
      private static final String URL="jdbc:sqlserver://localhost:1433;"
            + "databaseName=BasedeDatos_Licoreria;"+"integratedSecurity=true;"+
            "encrypt=true;trustServerCertificate=true";
    
    private static Conexion instancia=null;
    private static Connection conex=null; 
  
    public Conexion(){} //Contructor privado para para evitar crear instancia 
    
    public Connection conectar(){
        try{
            //usando Driver y cadena de conexion para conectar BD
            conex=DriverManager.getConnection(URL);
            System.out.println("Conexion establecida");
        return conex;
        
    }catch(SQLException e){
        System.out.println("Error de conexion: " + e);
   
    }
        return conex;
            
}
    
    public void cerrarConexion() throws SQLException{
        try{
            conex.close();
            System.out.println("Conexion Cerrada");   
        }catch(SQLException e){
           System.out.println("Error al cerrar conexion: " + e);
           conex. close();    
        }finally{
            conex.close();
        }  
    }
    //Crear una unica instancia de conexion 
    public static Conexion getInstance(){
        if(instancia==null){
            instancia=new Conexion();
        }
        return instancia;
    }
        }
