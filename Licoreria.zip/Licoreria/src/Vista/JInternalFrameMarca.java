package Vista;
import Controlador.MDIAPrincipal;
import Modeloo.DAOMarca;
import Modeloo.Marca;
import java.awt.HeadlessException;
import java.awt.event.KeyEvent;
import java.sql.SQLException;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JDialog;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

/*** @author Licoreria
 */
public class JInternalFrameMarca extends javax.swing.JInternalFrame {

    /***/
    public JInternalFrameMarca() {
        initComponents();
        jTextIdMarca.setEditable(false);
        obtenerDatos();
    }
    
     public void obtenerDatos(){ 
        try {
            List<Marca> marcas =new DAOMarca().ObtenerDatos();
            DefaultTableModel modelo =new DefaultTableModel();
            
            String[] columnas = {
                "Codigo_Marca", 
                "Etiqueta"};

            modelo.setColumnIdentifiers(columnas);
            for (Marca mar : marcas){
                String[] renglon ={Integer.toString(mar.getCodigo_Marca()),
                     mar.getEtiqueta()};
                modelo.addRow(renglon);
            }
           jTable_Marcas.setModel(modelo);//Ubica los datos del modelo en la tabla
        } catch (SQLException ex) {
            Logger.getLogger(JInternalFrameMarca.class.getName()).
                    log(Level.SEVERE, null, ex);
        }
        
         }
     
      public void actualizarMarca() throws SQLException {
       int id = Integer.parseInt(this.jTextIdMarca.getText());
       String et = this.jTextEtiqueta.getText();
       
       Marca marcas = new Marca(id, et);
       DAOMarca dao = new DAOMarca();
       int res = dao.Actualizar(marcas);
       if (res == 0) {
           JOptionPane.showMessageDialog(rootPane,
                   "¡Marca Actualizada!");
       } else {
           JOptionPane.showMessageDialog(rootPane,
                   "¡Ocurrio un ERROR!");
       }     
       } 
      
        public void limpiarCampos(){
        // Este método limpia los campos de la interfaz gráfica.
// Establece valores vacíos o nulos en varios componentes de la interfaz
        
// Establece el texto de los campos de texto a valores vacíos
        jTextIdMarca.setText("");
        jTextEtiqueta.setText("");
   
    }

    /***/
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jPanel7 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTable_Marcas = new javax.swing.JTable();
        jPanel3 = new javax.swing.JPanel();
        jLabel8 = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        jTextIdMarca = new javax.swing.JTextField();
        jTextEtiqueta = new javax.swing.JTextField();
        jLabel4 = new javax.swing.JLabel();
        jPanel15 = new javax.swing.JPanel();
        jLabel15 = new javax.swing.JLabel();
        jLabel16 = new javax.swing.JLabel();
        jButton1 = new javax.swing.JButton();
        jBAgregar1 = new javax.swing.JButton();
        jBEditar1 = new javax.swing.JButton();
        jBactualizar1 = new javax.swing.JButton();
        jBBorrar1 = new javax.swing.JButton();
        jTextFiltrar = new javax.swing.JTextField();
        jBBuscar1 = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();

        setIconifiable(true);

        jPanel1.setBackground(new java.awt.Color(202, 125, 48));

        jPanel7.setBackground(new java.awt.Color(202, 125, 48));
        jPanel7.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Lista de Marcas", javax.swing.border.TitledBorder.CENTER, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Segoe UI", 1, 24))); // NOI18N
        jPanel7.setForeground(new java.awt.Color(202, 125, 48));
        jPanel7.setLayout(new javax.swing.OverlayLayout(jPanel7));

        jTable_Marcas.setBackground(new java.awt.Color(232, 232, 232));
        jTable_Marcas.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        jTable_Marcas.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        jTable_Marcas.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null},
                {null, null},
                {null, null},
                {null, null}
            },
            new String [] {
                "ID", "Etiquetas"
            }
        ));
        jTable_Marcas.setGridColor(new java.awt.Color(204, 102, 0));
        jScrollPane1.setViewportView(jTable_Marcas);

        jPanel7.add(jScrollPane1);

        jPanel3.setBackground(new java.awt.Color(202, 125, 48));
        jPanel3.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        jPanel3.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        jPanel3.setOpaque(false);

        jLabel8.setBackground(new java.awt.Color(0, 0, 0));
        jLabel8.setFont(new java.awt.Font("Dialog", 0, 14)); // NOI18N
        jLabel8.setForeground(new java.awt.Color(255, 255, 255));
        jLabel8.setText("ID_Marca");

        jLabel11.setBackground(new java.awt.Color(0, 0, 0));
        jLabel11.setFont(new java.awt.Font("Dialog", 0, 14)); // NOI18N
        jLabel11.setForeground(new java.awt.Color(255, 255, 255));
        jLabel11.setText("Etiqueta");

        jTextIdMarca.setBackground(new java.awt.Color(232, 232, 232));
        jTextIdMarca.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        jTextEtiqueta.setBackground(new java.awt.Color(232, 232, 232));
        jTextEtiqueta.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        jTextEtiqueta.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                jTextEtiquetaKeyTyped(evt);
            }
        });

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(141, 141, 141)
                .addComponent(jLabel11)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                .addContainerGap(109, Short.MAX_VALUE)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jTextEtiqueta, javax.swing.GroupLayout.PREFERRED_SIZE, 124, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jTextIdMarca, javax.swing.GroupLayout.PREFERRED_SIZE, 124, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGap(26, 26, 26)
                        .addComponent(jLabel8)))
                .addGap(104, 104, 104))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                .addContainerGap(33, Short.MAX_VALUE)
                .addComponent(jLabel8)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jTextIdMarca, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jLabel11)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jTextEtiqueta, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(27, 27, 27))
        );

        jPanel15.setBackground(new java.awt.Color(255, 204, 102));
        jPanel15.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));

        jLabel16.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        jLabel16.setText("Registro de Marcas");

        jButton1.setBackground(new java.awt.Color(255, 204, 102));
        jButton1.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jButton1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Icon/Atras.png"))); // NOI18N
        jButton1.setText("Regresar");
        jButton1.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel15Layout = new javax.swing.GroupLayout(jPanel15);
        jPanel15.setLayout(jPanel15Layout);
        jPanel15Layout.setHorizontalGroup(
            jPanel15Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel15Layout.createSequentialGroup()
                .addGroup(jPanel15Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel15Layout.createSequentialGroup()
                        .addGap(430, 430, 430)
                        .addComponent(jLabel15))
                    .addGroup(jPanel15Layout.createSequentialGroup()
                        .addGap(68, 68, 68)
                        .addComponent(jButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 111, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(132, 132, 132)
                        .addComponent(jLabel16)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel15Layout.setVerticalGroup(
            jPanel15Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel15Layout.createSequentialGroup()
                .addGroup(jPanel15Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel16, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jButton1))
                .addGap(169, 169, 169)
                .addComponent(jLabel15)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jBAgregar1.setBackground(new java.awt.Color(182, 182, 188));
        jBAgregar1.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jBAgregar1.setForeground(new java.awt.Color(182, 182, 188));
        jBAgregar1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Icon/agregar.png"))); // NOI18N
        jBAgregar1.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        jBAgregar1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jBAgregar1ActionPerformed(evt);
            }
        });

        jBEditar1.setBackground(new java.awt.Color(182, 182, 188));
        jBEditar1.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jBEditar1.setForeground(new java.awt.Color(182, 182, 188));
        jBEditar1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Icon/editar.png"))); // NOI18N
        jBEditar1.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        jBEditar1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jBEditar1ActionPerformed(evt);
            }
        });

        jBactualizar1.setBackground(new java.awt.Color(182, 182, 188));
        jBactualizar1.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jBactualizar1.setForeground(new java.awt.Color(182, 182, 188));
        jBactualizar1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Icon/Actualizar.png"))); // NOI18N
        jBactualizar1.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        jBactualizar1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jBactualizar1ActionPerformed(evt);
            }
        });

        jBBorrar1.setBackground(new java.awt.Color(182, 182, 188));
        jBBorrar1.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jBBorrar1.setForeground(new java.awt.Color(182, 182, 188));
        jBBorrar1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Icon/eliminar.png"))); // NOI18N
        jBBorrar1.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        jBBorrar1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jBBorrar1ActionPerformed(evt);
            }
        });

        jTextFiltrar.setBackground(new java.awt.Color(232, 232, 232));
        jTextFiltrar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextFiltrarActionPerformed(evt);
            }
        });

        jBBuscar1.setBackground(new java.awt.Color(182, 182, 188));
        jBBuscar1.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jBBuscar1.setForeground(new java.awt.Color(182, 182, 188));
        jBBuscar1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Icon/buscar.png"))); // NOI18N
        jBBuscar1.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        jBBuscar1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jBBuscar1ActionPerformed(evt);
            }
        });

        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Icon/Logo Sencillo Neón para Bar.png"))); // NOI18N
        jLabel1.setText("jLabel1");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addComponent(jLabel4)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(419, 419, 419)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jPanel7, javax.swing.GroupLayout.PREFERRED_SIZE, 341, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(85, 85, 85)
                        .addComponent(jTextFiltrar, javax.swing.GroupLayout.PREFERRED_SIZE, 169, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(jBBuscar1, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGap(851, 851, 851)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(jBAgregar1, javax.swing.GroupLayout.DEFAULT_SIZE, 85, Short.MAX_VALUE)
                                    .addComponent(jBEditar1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(jBactualizar1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(jBBorrar1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 134, Short.MAX_VALUE))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jPanel15, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)))
                        .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 270, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(14, 14, 14))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(28, 28, 28)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 234, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 133, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jPanel15, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 7, Short.MAX_VALUE)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jPanel3, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                                        .addComponent(jBAgregar1, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(58, 58, 58)))
                                .addGap(18, 18, 18)
                                .addComponent(jPanel7, javax.swing.GroupLayout.PREFERRED_SIZE, 257, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                                .addComponent(jBEditar1, javax.swing.GroupLayout.PREFERRED_SIZE, 46, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(jBactualizar1, javax.swing.GroupLayout.PREFERRED_SIZE, 46, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(jBBorrar1, javax.swing.GroupLayout.PREFERRED_SIZE, 46, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jTextFiltrar, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                                        .addGap(24, 24, 24)
                                        .addComponent(jBBuscar1)))))))
                .addGap(109, 109, 109))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jBAgregar1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jBAgregar1ActionPerformed

         String eti = jTextEtiqueta.getText();
        // Agregar validacines a cajas de texto segun fromato y
        // caracteres validos a ingresar
        // comprueba que las cajas de texto no esten vacias
        if (eti.contentEquals("")) {
            JOptionPane.showMessageDialog(rootPane,
                "Todos los campos son obligatorios de llenar");
        } else {
            try {
                //Objeto para pasar valores a método Insertar de DAOAutor
                Marca marcas = new Marca(eti);
                DAOMarca dao = new DAOMarca();
                if (dao.Insertar(marcas) == 0) {
                    JOptionPane.showMessageDialog(rootPane,
                        "Marca agregada");
                }

            } catch (HeadlessException | SQLException e) {
                JOptionPane.showMessageDialog(rootPane,
                    "No se agrego la Marca");
            }

        }
        obtenerDatos(); //Llama a este metodo para que se muestre el nuevo
        //Registro en la tabla del formulario
        limpiarCampos();   //Llama a este metodo para limpiar las cajas de texto
    }//GEN-LAST:event_jBAgregar1ActionPerformed

    private void jBEditar1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jBEditar1ActionPerformed
         // Este método se activa al hacer clic en un botón (jBEditar) en la interfaz.
        // Selecciona un registro de la tabla y permite editar sus detalles.
        // Obtiene la fila seleccionada en la tabla jTable_Autor
        int fila = this.jTable_Marcas.getSelectedRow(); //Se obtiene @fila seleccionado
        if(fila == -1) {
            // Si no se selecciona ninguna fila, muestra un mensaje de advertencia
            JOptionPane.showMessageDialog(rootPane,
                "Seleccione una marca de la tabla");
        } else { //Se toma cada campo de la tabla del registro seleccionado
            // Y se asigna a una variable
            try {
                // Obtiene los datos de la fila seleccionada en la tabla y los muestra
                // en los campos de la interfaz
                int id = Integer.parseInt((String)this.jTable_Marcas.
                    getValueAt(fila, 0).toString());
                String etiq = (String) this.jTable_Marcas.getValueAt(fila,1);

                // Se ubican en las cajas de txtos los datos capturados de la tabla
                jTextIdMarca.setText("" +id);
                jTextEtiqueta.setText(etiq);
            } catch (NumberFormatException e) {
                JOptionPane.showMessageDialog(rootPane,
                    "¡Ocurrió un ERROR! "+e.getMessage());
            }
        }
    }//GEN-LAST:event_jBEditar1ActionPerformed

    private void jBactualizar1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jBactualizar1ActionPerformed
         try {
            actualizarMarca();
        } catch (SQLException ex) {
            Logger.getLogger(JInternalFrameMarca.class.getName()).
            log(Level.SEVERE, null, ex);
        }
        obtenerDatos();
        limpiarCampos();
    }//GEN-LAST:event_jBactualizar1ActionPerformed

    private void jBBorrar1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jBBorrar1ActionPerformed
        // Este método se activa al hacer clic en el botón "Borrar" en la interfaz.
        // Obtiene la fila seleccionada en la tabla jTable_Autor.
        int fila = this.jTable_Marcas.getSelectedRow();
        if (fila ==-1){
            // Si no se ha seleccionado ninguna fila, muestra un mensaje de advertencia.
            JOptionPane.showMessageDialog(rootPane,
                "Seleccione una marca de la tabla");
        } else {

            JDialog.setDefaultLookAndFeelDecorated(true);
            int resp = JOptionPane.showConfirmDialog(null,
                "¿Esta seguro de eliminar esta marca?", "Aceptar"
                ,JOptionPane.YES_NO_OPTION
                ,JOptionPane.QUESTION_MESSAGE);
            if(resp == JOptionPane.NO_OPTION) {
                JOptionPane.showMessageDialog(rootPane,
                    "Marca no borrada");
            }else {
                if (resp == JOptionPane.YES_OPTION) {
                    try {
                        int id = Integer.parseInt((String) this.jTable_Marcas.
                            getValueAt(fila, 0).toString());
                        DAOMarca dao = new DAOMarca();
                        dao.Eliminar (id);
                        obtenerDatos();
                    } catch (SQLException ex) {
                        Logger.getLogger( JInternalFrameMarca.class.getName()).
                        log(Level.SEVERE,null,ex);
                    }
                }
            }
            if (resp == JOptionPane.CLOSED_OPTION) {
                JOptionPane.showMessageDialog(rootPane,
                    "Ninguna acción realizada");
            }

        }
    }//GEN-LAST:event_jBBorrar1ActionPerformed

    private void jTextFiltrarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextFiltrarActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextFiltrarActionPerformed

    private void jBBuscar1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jBBuscar1ActionPerformed
         String criterio = jTextFiltrar.getText().trim();
        if(criterio.isEmpty()){
            JOptionPane.showMessageDialog(this,
                    "por favor, ingrese un registro de busqueda.",
                    "Información", JOptionPane.INFORMATION_MESSAGE);
            obtenerDatos();
            return;
        }
        
        try{
            List<Marca> marcas = new DAOMarca().ObtenerDatos();
            DefaultTableModel modelo = new  DefaultTableModel();
            String[] columnas = {"Codigo_Marca", "Etiqueta"};
            modelo.setColumnIdentifiers(columnas);
            
            //Convertir criterio a numero si es posible
            Integer criterioID = null;
            try{
                criterioID = Integer.parseInt(criterio);
            } catch (NumberFormatException e){
                // No hacer nada, criterio no es un numero
            }
            
            for (Marca marca : marcas) {
                boolean coincide = false;
                
                // comparar con IDcliente si criterio es númerico
                if(criterioID != null){
                    if(marca.getCodigo_Marca()== criterioID){
                        coincide = true;
                    }
                } else{
                    //Comparar con otros campos si criterio es texto
                    if(marca.getEtiqueta().toLowerCase().contains(criterio.toLowerCase())||
                       marca.getEtiqueta().contains(criterio)) {
                        coincide = true;
                    }
                }
                if(coincide){
                String[] renglon = {
                    Integer.toString(marca.getCodigo_Marca()),
                    marca.getEtiqueta()
                };
                modelo.addRow(renglon);
                }
            }
            jTable_Marcas.setModel(modelo);
            if(modelo.getRowCount() == 0){
                JOptionPane.showMessageDialog(this,
                        "No se encontraron resultados para el registro de busqueda.",
                        "Información", JOptionPane.INFORMATION_MESSAGE);
            }
        } catch (SQLException ex){
            Logger.getLogger(Marca.class.getName()).log(Level.SEVERE, null, ex);
            JOptionPane.showMessageDialog(this,
                    "Ocurrió un error a realizar la búsqueda.", "Error",
                    JOptionPane.ERROR_MESSAGE);
        }
    }//GEN-LAST:event_jBBuscar1ActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        MDIAPrincipal TK = null;
        TK = new MDIAPrincipal();
        TK.setVisible(true);
    }//GEN-LAST:event_jButton1ActionPerformed

    private void jTextEtiquetaKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jTextEtiquetaKeyTyped
        char car = evt.getKeyChar();
        if ((car < 'a' || car > 'z') && (car < 'A' || car > 'z')
            && car != 'á' //Minúsculas
            && car != 'é'
            && car != 'í'
            && car != 'ó'
            && car != 'ú'
            && car != 'Á' //Mayusculas
            && car != 'É'
            && car != 'Í'
            && car != 'Ó'
            && car != 'Ú'
            && car != 'Ü'
            && car != 'ü'
            && car != 'Ñ'
            && car != 'ñ'
            && (car != (char) KeyEvent.VK_SPACE)) {
            evt.consume();
        }
    }//GEN-LAST:event_jTextEtiquetaKeyTyped


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jBAgregar1;
    private javax.swing.JButton jBBorrar1;
    private javax.swing.JButton jBBuscar1;
    private javax.swing.JButton jBEditar1;
    private javax.swing.JButton jBactualizar1;
    private javax.swing.JButton jButton1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel15;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel7;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable jTable_Marcas;
    private javax.swing.JTextField jTextEtiqueta;
    private javax.swing.JTextField jTextFiltrar;
    private javax.swing.JTextField jTextIdMarca;
    // End of variables declaration//GEN-END:variables
}
