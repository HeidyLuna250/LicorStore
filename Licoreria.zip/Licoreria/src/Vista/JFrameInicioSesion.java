package Vista;
import Controlador.MDIAPrincipal;
import java.awt.Image;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import javax.swing.JButton;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;

/**
 *
 * @author DELL
 */
public class JFrameInicioSesion extends javax.swing.JFrame {

    /***/
    public JFrameInicioSesion() {
        initComponents();
        setIconImage(getIconImage());
    }
    
    //Icono del frame
       @Override 
     public Image getIconImage (){
         Image retValue = Toolkit.getDefaultToolkit().getImage(ClassLoader.
                 getSystemResource("Icon\\Logo.png"));    
         return retValue;
         
     }
     
      //Para el boton mostrar
public abstract class MostrarContraseña extends JFrameInicioSesion implements ActionListener {
    private JPasswordField Contraseña;
    private JButton botonMostrar;
    
        public MostrarContraseña() {
        setTitle("Mostrar Contraseña");
        setDefaultCloseOperation(JFrameInicioSesion.EXIT_ON_CLOSE);
        
        // Crear el campo de contraseña
        Contraseña = new JPasswordField(20);
        
        // Crear el botón
        botonMostrar = new JButton("Mostrar Contraseña");
        botonMostrar.addActionListener(this);
        
        // Crear el panel y agregar componentes
        JPanel panel = new JPanel();
        panel.add(Contraseña);
        panel.add(botonMostrar);
        
        // Agregar el panel al frame
        add(panel);
        
        pack();
        setVisible(true);
    }
        
        public void actionPerformed(ActionEvent e) {
        if (e.getSource() == botonMostrar) {
            // Si el botón de mostrar contraseña es presionado, cambiar el campo de contraseña a texto visible
            Contraseña.setEchoChar((char)0); // Mostrar texto plano
        }
    }
        }

    /***/
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jTextFieldUsuario = new javax.swing.JTextField();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jButtonIngresar = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        jPasswordFieldContraseña = new javax.swing.JPasswordField();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jCheckBoxMostrar = new javax.swing.JCheckBox();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(202, 125, 48));
        jPanel1.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        jPanel1.setForeground(new java.awt.Color(202, 125, 48));
        jPanel1.setMaximumSize(new java.awt.Dimension(2147483647, 2147483647));

        jTextFieldUsuario.setBackground(new java.awt.Color(232, 232, 232));
        jTextFieldUsuario.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jTextFieldUsuario.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        jTextFieldUsuario.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextFieldUsuarioActionPerformed(evt);
            }
        });

        jLabel2.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(255, 255, 255));
        jLabel2.setText("Usuario");

        jLabel3.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(255, 255, 255));
        jLabel3.setText("Contraseña");

        jButtonIngresar.setBackground(new java.awt.Color(182, 182, 188));
        jButtonIngresar.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jButtonIngresar.setText("INGRESAR");
        jButtonIngresar.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        jButtonIngresar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonIngresarActionPerformed(evt);
            }
        });

        jPasswordFieldContraseña.setBackground(new java.awt.Color(232, 232, 232));
        jPasswordFieldContraseña.setText("jPasswordField1");
        jPasswordFieldContraseña.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));

        jLabel5.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Icon/Logo Sencillo Neón para Bar.png"))); // NOI18N

        jCheckBoxMostrar.setBackground(new java.awt.Color(202, 125, 48));
        jCheckBoxMostrar.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jCheckBoxMostrar.setForeground(new java.awt.Color(255, 255, 255));
        jCheckBoxMostrar.setText("Mostrar Contraseña");
        jCheckBoxMostrar.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        jCheckBoxMostrar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jCheckBoxMostrarActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(258, 258, 258)
                        .addComponent(jLabel1)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGap(321, 321, 321)
                                .addComponent(jLabel4))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGap(256, 256, 256)
                                .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 274, javax.swing.GroupLayout.PREFERRED_SIZE))))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(646, 646, 646)
                        .addComponent(jLabel2))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(636, 636, 636)
                        .addComponent(jLabel3))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(582, 582, 582)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(jTextFieldUsuario, javax.swing.GroupLayout.DEFAULT_SIZE, 198, Short.MAX_VALUE)
                            .addComponent(jPasswordFieldContraseña)))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(603, 603, 603)
                        .addComponent(jCheckBoxMostrar))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(642, 642, 642)
                        .addComponent(jButtonIngresar, javax.swing.GroupLayout.PREFERRED_SIZE, 83, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(846, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(174, 174, 174)
                        .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 133, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(40, 40, 40)
                        .addComponent(jLabel4)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 242, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(57, 57, 57)
                .addComponent(jLabel2)
                .addGap(18, 18, 18)
                .addComponent(jTextFieldUsuario, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jLabel3)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jPasswordFieldContraseña, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jCheckBoxMostrar)
                .addGap(31, 31, 31)
                .addComponent(jButtonIngresar)
                .addContainerGap(312, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 1640, Short.MAX_VALUE)
            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 918, Short.MAX_VALUE)
            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jTextFieldUsuarioActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextFieldUsuarioActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextFieldUsuarioActionPerformed

    private void jButtonIngresarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonIngresarActionPerformed

        if (jTextFieldUsuario.getText().contentEquals("")||
            jPasswordFieldContraseña.getText().contentEquals("")){

            JOptionPane.showMessageDialog(null, "Ingrese Contraseña",
                "!Verifique el campo de la contraseña¡",JOptionPane.WARNING_MESSAGE);
        }
        else {
            MDIAPrincipal mdiFarmacia1 = new MDIAPrincipal();
            mdiFarmacia1.setVisible(true);
            JOptionPane.showMessageDialog(null,jTextFieldUsuario.
                getText(),"Bienvenid@:",JOptionPane.INFORMATION_MESSAGE);
        }
    }//GEN-LAST:event_jButtonIngresarActionPerformed

    private void jCheckBoxMostrarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jCheckBoxMostrarActionPerformed

    }//GEN-LAST:event_jCheckBoxMostrarActionPerformed

       public static void main(String args[]) {
    // Crear una instancia del formulario de inicio de sesión
           JFrameInicioSesion InicioSecion = new JFrameInicioSesion();

        // Mostrar el formulario de inicio de sesión primero
        InicioSecion.setVisible(true);

        // Esperar hasta que el formulario de inicio de sesión se cierre
        InicioSecion.addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosed(WindowEvent e) {
                // Una vez que el formulario de inicio de sesión se cierre, mostrar el MDI o la ventana principal

            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButtonIngresar;
    private javax.swing.JCheckBox jCheckBoxMostrar;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPasswordField jPasswordFieldContraseña;
    private javax.swing.JTextField jTextFieldUsuario;
    // End of variables declaration//GEN-END:variables
}
