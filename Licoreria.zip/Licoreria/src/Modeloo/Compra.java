package Modeloo;

/*** @author Compra
 */
public class Compra {
    
}
