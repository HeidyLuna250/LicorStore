package Modeloo;

/*** @author Licoreria
 */
public class Marca {
    private int Codigo_Marca;
    private String Etiqueta;

    
    public Marca(int Codigo_Marca, String Etiqueta) {
        this.Codigo_Marca = Codigo_Marca;
        this.Etiqueta = Etiqueta;
    }

    public Marca(String Etiqueta) {
        this.Etiqueta = Etiqueta;
    }

    public int getCodigo_Marca() {
        return Codigo_Marca;
    }

    public void setCodigo_Marca(int Codigo_Marca) {
        this.Codigo_Marca = Codigo_Marca;
    }

    public String getEtiqueta() {
        return Etiqueta;
    }

    public void setEtiqueta(String Etiqueta) {
        this.Etiqueta = Etiqueta;
    }
    
}


