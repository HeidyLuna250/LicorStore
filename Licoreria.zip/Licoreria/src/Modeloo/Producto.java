package Modeloo;

/*** @author Licoreria
 */
public class Producto {
    
}
