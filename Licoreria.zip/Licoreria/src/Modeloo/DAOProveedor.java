package Modeloo;
import Modelo.Conexion.Conexion;
import java.sql.CallableStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/*** @author Licoreria
 */
public class DAOProveedor {
     //Crear una instancia de conexión
    //Hace llamado al método getInstance
    Conexion conectar=Conexion.getInstance();
    //Método para seleccionar todos los registros de la tabla
    
    //Codigo para obtener datos de la base de datos 
    public List ObtenerDatos() throws SQLException{
        //Nombre del procedimiento almacenado
        String proced= "sp_ObtenerProveedor()";
        //Llama a metodo Listar de DataBase.java, se le pasa nombre del proc.
        List<Map> registros= new DataBase().Listar(proced);
        List<Proveedor> proveedores = new ArrayList();//Arreglo de Proveedores
        //Ciclo que recorre cada registro y los agrega al arreglo Proveedores
        for (Map registro : registros) {
            Proveedor pro =new Proveedor ((int) registro.get("Codigo_Proveedor"),
                    (String) registro.get("Nombre"),
                    (String) registro.get ("Apellido"),
                    (String) registro.get("Telefono"),
                    (String) registro.get("Empresa"),
                    (String) registro.get("Direccion"));
                proveedores.add(pro);
            
        }
         return proveedores; //Retorna todos los clientes en la tabla de BD
    
    }
    
    // Codigo de insetrtar, (ingrsar datos)
    public int Insertar(Proveedor aut) throws SQLException {
        try{ //Para manejar errores al realizar la conexion y transacción en BD 
            
            //Llama a procedimiento almacenado de SQLServer 
            CallableStatement st=conectar.conectar().
                    prepareCall("{CALL sp_InsertarProveedor(?,?,?,?,?)}");

            st.setString(1, aut.getNombre()); //Pasando parametros a
            st.setString(2, aut.getApellido());
            st.setString(3, aut.getTelefono());
            st.setString(4, aut.getEmpresa());   
            st.setString(5, aut.getDireccion());
            st.executeUpdate();
            
    }catch (SQLException e){
            System.out.println(e+" ERROR ");
            conectar.cerrarConexion();
            return -1;
      } 
        
        conectar.cerrarConexion();
        return 0;
    }
    
    public int Actualizar(Proveedor aut) throws SQLException {
         try{ //Para manejar errores al realizar la conexion y transaccion en BD
             CallableStatement st = conectar.conectar().
                     prepareCall("{CALL sp_ActualizarProveedor(?,?,?,?,?,?)}");
                st.setInt(1, aut.getCodigo_Proveedor());
            st.setString(2, aut.getNombre());
            st.setString(3, aut.getApellido());
            st.setString(4, aut.getTelefono());   
            st.setString(5, aut.getEmpresa());
            st.setString(6, aut.getDireccion());
            st.executeUpdate();
            
              }catch (SQLException e){
            System.out.println(e+" ERROR ");
            conectar.cerrarConexion();
            return -1;
      } 
        
        conectar.cerrarConexion();
        return 0;
    }
    
    public int Eliminar(int id) throws SQLException {
         try{ //Para manejar errores al realizar la conexion y transaccion en BD
             
             CallableStatement st=conectar.conectar().
                     prepareCall("{CALL sp_BorrarProveedor(?)}");
        
                st.setInt(1, id);
                st.executeUpdate();
            
              }catch (SQLException e){
            System.out.println(e+" ERROR ");
            conectar.cerrarConexion();
            return -1;
      } 
        
        conectar.cerrarConexion();
        return 0;
    }
    
    public List<Proveedor> Buscar(Integer Codigo_Proveedor, String Nombre,
            String Apellido, String Telefono, String Empresa, String Direccion) throws SQLException{
        List<Proveedor> proveedores = new ArrayList<>();
        CallableStatement st = null;
        ResultSet rs= null;
        
        try{
            st = conectar.conectar().prepareCall("{CALL SP_BuscarProveedor(?,?,?,?,?,?)}");
            //Establecer parámetros
            if(Codigo_Proveedor!=null){
                st.setInt(1, Codigo_Proveedor);
            } else{
                st.setNull(1, java.sql.Types.INTEGER);
            }
            st.setString(2, Nombre != null ? Nombre : "");
            st.setString(3, Apellido != null ? Apellido : "");
            st.setString(4, Telefono != null ? Telefono : "");
            st.setString(5, Empresa != null ? Empresa : "");
            st.setString(6, Direccion != null ? Direccion : "");
            
            rs = st.executeQuery();
            
          while (rs.next()){
            }
        } catch (SQLException e){
            System.out.println(e + " Error ");
            return null;
        } finally{
            if (rs != null) rs.close();
            if(st != null) st.close();
            conectar.cerrarConexion();
        }
        return proveedores;
    }
}

