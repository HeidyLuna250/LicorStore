package Modeloo;
import Modelo.Conexion.Conexion;
import java.sql.CallableStatement;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import Modelo.Conexion.Conexion;
import Modeloo.DataBase;
import Modeloo.DAOTiposProductos;
import java.sql.CallableStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/*** @author Licoreria
 */
public class DAOTiposProductos {
        //Crear una instancia de conexión
    //Hace llamado al método getInstance
    Conexion conectar=Conexion.getInstance();
    //Método para seleccionar todos los registros de la tabla
    
    //Codigo para obtener datos de la base de datos 
    public List ObtenerDatos() throws SQLException{
        //Nombre del procedimiento almacenado
        String proced= "sp_ObtenerTipo_Producto()";
        //Llama a metodo Listar de DataBase.java, se le pasa nombre del proc.
        List<Map> registros= new DataBase().Listar(proced);
        List<TiposProductos> tiposproductos = new ArrayList();//Arreglo de TiposProductos
        //Ciclo que recorre cada registro y los agrega al arreglo TiposProductos
        for (Map registro : registros) {
              TiposProductos pro =new TiposProductos ((int) registro.get("Codigo_Tipo_Producto"),
                    (String) registro.get("Nombre"));
                 tiposproductos.add(pro);
                
        }
         return tiposproductos; //Retorna todos las marcas en la tabla de BD
    
    }
    
    // Codigo de insetrtar, (ingrsar datos)
    public int Insertar(TiposProductos pr) throws SQLException {
        try{ //Pra manejar errores al realizar la conexion y transacción en BD 
            
            //Llama a procedimiento almacenado de SQLServer 
            CallableStatement st=conectar.conectar().
                    prepareCall("{CALL sp_InsertarTipo_Producto(?)}");

            st.setString(1, pr.getNombre()); //Pasando parametros a
            st.executeUpdate();
            
    }catch (SQLException e){
            System.out.println(e+" ERROR ");
            conectar.cerrarConexion();
            return -1;
      } 
        
        conectar.cerrarConexion();
        return 0;
    }
    
    public int Actualizar(TiposProductos pr) throws SQLException {
         try{ //Para manejar errores al realizar la conexion y transaccion en BD
             CallableStatement st=conectar.conectar().
                     prepareCall("{CALL sp_ActualizarTipo_Producto(?)}");
            st.setInt(1, pr.getCodigo_Tipo_Producto());
            st.setString(2, pr.getNombre()); //Pasando parametros a
            st.executeUpdate();
            
              }catch (SQLException e){
            System.out.println(e+" ERROR ");
            conectar.cerrarConexion();
            return -1;
      } 
        
        conectar.cerrarConexion();
        return 0;
    }
    
     public int Eliminar(int id) throws SQLException {
         try{ //Para manejar errores al realizar la conexion y transaccion en BD
             
             CallableStatement st=conectar.conectar().
                     prepareCall("{CALL sp_BorrarTipo_Producto(?)}");
        
                st.setInt(1, id);
                st.executeUpdate();
            
              }catch (SQLException e){
            System.out.println(e+" ERROR ");
            conectar.cerrarConexion();
            return -1;
      } 
        
        conectar.cerrarConexion();
        return 0;
    }
     public List<TiposProductos> Buscar(Integer Codigo_Tipo_Producto, 
             String Nombre) throws SQLException{
        List<TiposProductos> tiposproductos = new ArrayList<>();
        CallableStatement st = null;
        ResultSet rs= null;
        
        try{
            st = conectar.conectar().prepareCall("{CALL SP_BuscarTipo_Producto(?,?)}");
            //Establecer parámetros
            if(Codigo_Tipo_Producto!=null){
                st.setInt(1, Codigo_Tipo_Producto);
            } else{
                st.setNull(1, java.sql.Types.INTEGER);
            }
            st.setString(2, Nombre != null ? Nombre : "");
            
            rs = st.executeQuery();
            
          while (rs.next()){
                TiposProductos tipoProducto = new TiposProductos(
                        rs.getInt("Codigo_Tipo_Producto"),
                        rs.getString("Nombre"));
                tiposproductos.add(tipoProducto);
            }
        } catch (SQLException e){
            System.out.println(e + " Error ");
            return null;
        } finally{
            if (rs != null) rs.close();
            if(st != null) st.close();
            conectar.cerrarConexion();
        }
        return tiposproductos;
    }
    
}