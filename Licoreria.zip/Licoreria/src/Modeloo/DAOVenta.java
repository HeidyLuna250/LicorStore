package Modeloo;
import Modelo.Conexion.Conexion;
import java.sql.CallableStatement;
import java.sql.Date;
import java.sql.SQLException;
import javax.swing.JOptionPane;

/*** @author Licoreria
 */
public class DAOVenta {

    
}
