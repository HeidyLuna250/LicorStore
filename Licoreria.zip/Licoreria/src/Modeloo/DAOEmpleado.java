package Modeloo;
import Modelo.Conexion.Conexion;
import java.sql.CallableStatement;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import Modelo.Conexion.Conexion;
import Modeloo.DataBase;
import Modeloo.Empleado;
import java.sql.CallableStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/*** @author Licoreria
 */
public class DAOEmpleado {
     //Crear una instancia de conexión
    //Hace llamado al método getInstance
    Conexion conectar=Conexion.getInstance();
    //Método para seleccionar todos los registros de la tabla
    
    //Codigo para obtener datos de la base de datos 
    public List ObtenerDatos() throws SQLException{
        //Nombre del procedimiento almacenado
        String proced= "sp_ObtenerEmpleado()";
        //Llama a metodo Listar de DataBase.java, se le pasa nombre del proc.
        List<Map> registros= new DataBase().Listar(proced);
        List<Empleado> empleados = new ArrayList();//Arreglo de Emplados
        //Ciclo que recorre cada registro y los agrega al arreglo Emplados
        for (Map registro : registros) {
              Empleado em =new Empleado ((int) registro.get("Codigo_Empleado"),
                    (String) registro.get("Nombre"),
                    (String) registro.get ("Apellido"),
                    (String) registro.get("CedulaEmpleado"));
                empleados.add(em);
            
        }
         return empleados; //Retorna todos los clientes en la tabla de BD
    
    }
    
      // Codigo de insetrtar, (ingrsar datos)
    public int Insertar(Empleado aut) throws SQLException {
        try{ //Pra manejar errores al realizar la conexion y transacción en BD 
            
            //Llama a procedimiento almacenado de SQLServer 
            CallableStatement st=conectar.conectar().
                    prepareCall("{CALL sp_InsertarEmpleado(?,?,?)}");

            st.setString(1, aut.getNombre()); //Pasando parametros a
            st.setString(2, aut.getApellido());
            st.setString(3, aut.getCedulaEmpleado()); 
            st.executeUpdate();
            
    }catch (SQLException e){
            System.out.println(e+" ERROR ");
            conectar.cerrarConexion();
            return -1;
      } 
        
        conectar.cerrarConexion();
        return 0;
    }
    
    public int Actualizar(Empleado emp) throws SQLException {
         try{ //Para manejar errores al realizar la conexion y transaccion en BD
             CallableStatement st=conectar.conectar().
                     prepareCall("{CALL sp_ActualizarEmpleado(?,?,?,?)}");
            st.setInt(1, emp.getCodigo_Empleado());
            st.setString(2, emp.getNombre()); //Pasando parametros a
            st.setString(3, emp.getApellido());
            st.setString(4, emp.getCedulaEmpleado()); 
            st.executeUpdate();
            
              }catch (SQLException e){
            System.out.println(e+" ERROR ");
            conectar.cerrarConexion();
            return -1;
      } 
        
        conectar.cerrarConexion();
        return 0;
    }
    
      public int Eliminar(int id) throws SQLException {
         try{ //Para manejar errores al realizar la conexion y transaccion en BD
             
             CallableStatement st=conectar.conectar().
                     prepareCall("{CALL sp_EliminarEmpleado(?)}");
        
                st.setInt(1, id);
                st.executeUpdate();
            
              }catch (SQLException e){
            System.out.println(e+" ERROR ");
            conectar.cerrarConexion();
            return -1;
      } 
        
        conectar.cerrarConexion();
        return 0;
    }
      
      public List<Empleado> Buscar(Integer Codigo_Empleado, String Nombre,
            String Apellido, String CedulaEmpleado) throws SQLException{
        List<Empleado> empleados = new ArrayList<>();
        CallableStatement st = null;
        ResultSet rs= null;
        
        try{
            st = conectar.conectar().prepareCall("{CALL SP_BuscarEmpleado(?,?,?,?)}");
            //Establecer parámetros
            if(Codigo_Empleado!=null){
                st.setInt(1, Codigo_Empleado);
            } else{
                st.setNull(1, java.sql.Types.INTEGER);
            }
            st.setString(2, Nombre != null ? Nombre : "");
            st.setString(3, Apellido != null ? Apellido : "");
            st.setString(4, CedulaEmpleado != null ? CedulaEmpleado : "");
            
            rs = st.executeQuery();
            
          while (rs.next()){
                Empleado empleado = new Empleado(
                        rs.getInt("Codigo_Empleado"),
                        rs.getString("Nombre"),
                        rs.getString("Apellido"),
                        rs.getString("CedulaEmpleado"));
                empleados.add(empleado);
            }
        } catch (SQLException e){
            System.out.println(e + " Error ");
            return null;
        } finally{
            if (rs != null) rs.close();
            if(st != null) st.close();
            conectar.cerrarConexion();
        }
        return empleados;
    }
}