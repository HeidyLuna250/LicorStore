package Modeloo;

/*** @author Licoreria
 */
public class TiposProductos {
    private int Codigo_Tipo_Producto;
    private String Nombre;

    public TiposProductos(int Codigo_Tipo_Producto, String Nombre) {
        this.Codigo_Tipo_Producto = Codigo_Tipo_Producto;
        this.Nombre = Nombre;
    }

    public TiposProductos(String Nombre) {
        this.Nombre = Nombre;
    }

    public int getCodigo_Tipo_Producto() {
        return Codigo_Tipo_Producto;
    }

    public void setCodigo_Tipo_Producto(int Codigo_Tipo_Producto) {
        this.Codigo_Tipo_Producto = Codigo_Tipo_Producto;
    }

    public String getNombre() {
        return Nombre;
    }

    public void setNombre(String Nombre) {
        this.Nombre = Nombre;
    }
    
    public String toString() {
        return Codigo_Tipo_Producto + " - " + Nombre;
    }
    
}
