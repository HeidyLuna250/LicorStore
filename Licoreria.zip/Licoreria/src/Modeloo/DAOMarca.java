package Modeloo;
import Modelo.Conexion.Conexion;
import java.sql.CallableStatement;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import Modelo.Conexion.Conexion;
import Modeloo.DataBase;
import Modeloo.Marca;
import java.sql.CallableStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/*** @author Licoreria
 */
public class DAOMarca {
        //Crear una instancia de conexión
    //Hace llamado al método getInstance
    Conexion conectar=Conexion.getInstance();
    //Método para seleccionar todos los registros de la tabla
    
    //Codigo para obtener datos de la base de datos 
    public List ObtenerDatos() throws SQLException{
        //Nombre del procedimiento almacenado
        String proced= "sp_ObtenerMarcas()";
        //Llama a metodo Listar de DataBase.java, se le pasa nombre del proc.
        List<Map> registros= new DataBase().Listar(proced);
        List<Marca> marcas = new ArrayList();//Arreglo de Marca
        //Ciclo que recorre cada registro y los agrega al arreglo Marca
        for (Map registro : registros) {
              Marca mar =new Marca ((int) registro.get("Codigo_Marca"),
                    (String) registro.get("Etiqueta"));
                marcas.add(mar);
            
        }
         return marcas; //Retorna todos las marcas en la tabla de BD
    
    }
    
    // Codigo de insetrtar, (ingrsar datos)
    public int Insertar(Marca mar) throws SQLException {
        try{ //Pra manejar errores al realizar la conexion y transacción en BD 
            
            //Llama a procedimiento almacenado de SQLServer 
            CallableStatement st=conectar.conectar().
                    prepareCall("{CALL sp_InsertarMarcas(?)}");

            st.setString(1, mar.getEtiqueta()); //Pasando parametros a
            st.executeUpdate();
            
    }catch (SQLException e){
            System.out.println(e+" ERROR ");
            conectar.cerrarConexion();
            return -1;
      } 
        
        conectar.cerrarConexion();
        return 0;
    }
    
     public int Actualizar(Marca mar) throws SQLException {
         try{ //Para manejar errores al realizar la conexion y transaccion en BD
             CallableStatement st=conectar.conectar().
                     prepareCall("{CALL sp_ActualizarMarcas(?,?)}");
            st.setInt(1, mar.getCodigo_Marca());
            st.setString(2, mar.getEtiqueta()); //Pasando parametros a
            st.executeUpdate();
            
              }catch (SQLException e){
            System.out.println(e+" ERROR ");
            conectar.cerrarConexion();
            return -1;
      } 
        
        conectar.cerrarConexion();
        return 0;
    }
     
      public int Eliminar(int id) throws SQLException {
         try{ //Para manejar errores al realizar la conexion y transaccion en BD
             
             CallableStatement st=conectar.conectar().
                     prepareCall("{CALL sp_BorrarMarcas(?)}");
        
                st.setInt(1, id);
                st.executeUpdate();
            
              }catch (SQLException e){
            System.out.println(e+" ERROR ");
            conectar.cerrarConexion();
            return -1;
      } 
        
        conectar.cerrarConexion();
        return 0;
    }
      
       public List<Marca> Buscar(Integer Codigo_Marca, String Etiqueta) throws SQLException{
        List<Marca> marcas = new ArrayList<>();
        CallableStatement st = null;
        ResultSet rs= null;
        
        try{
            st = conectar.conectar().prepareCall("{CALL SP_BuscarMarcas(?,?)}");
            //Establecer parámetros
            if(Codigo_Marca!=null){
                st.setInt(1, Codigo_Marca);
            } else{
                st.setNull(1, java.sql.Types.INTEGER);
            }
            st.setString(2, Etiqueta != null ? Etiqueta : "");
            
            rs = st.executeQuery();
            
          while (rs.next()){
                Marca marca = new Marca(
                        rs.getInt("Codigo_Marca"),
                        rs.getString("Etiqueta"));
                marcas.add(marca);
            }
        } catch (SQLException e){
            System.out.println(e + " Error ");
            return null;
        } finally{
            if (rs != null) rs.close();
            if(st != null) st.close();
            conectar.cerrarConexion();
        }
        return marcas;
    }
    
}
