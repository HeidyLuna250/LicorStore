package Modeloo;

/*** @author Licoreria
 */
public class DAOCompra {
    
}
